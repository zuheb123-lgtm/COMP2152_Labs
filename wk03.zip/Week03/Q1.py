#Question 1

grades = [85, 92, 78, 95, 88]
grades.append(90)
grades.sort()
print(f"Sorted grades: {grades}")

print(f"Highest grades: {grades [-1] }")
print(f"Lowest grades: {grades [0] }")
print(f"Total Number of grades: {len(grades)}")